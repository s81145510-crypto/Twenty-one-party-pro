from __future__ import annotations
from datetime import datetime, timezone
from sqlalchemy import UniqueConstraint, CheckConstraint, Index
from .extensions import db


def utcnow():
    return datetime.now(timezone.utc)

class User(db.Model):
    __tablename__ = "users"
    id = db.Column(db.BigInteger, primary_key=True)  # Telegram user id
    username = db.Column(db.String(64), nullable=False, default="User")
    photo_url = db.Column(db.String(500), nullable=False, default="")
    bio = db.Column(db.String(300), nullable=False, default="")
    phone = db.Column(db.String(20), nullable=False, default="")
    coins = db.Column(db.BigInteger, nullable=False, default=100)
    earnings = db.Column(db.BigInteger, nullable=False, default=0)
    banned = db.Column(db.Boolean, nullable=False, default=False)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow)

class Room(db.Model):
    __tablename__ = "rooms"
    id = db.Column(db.String(64), primary_key=True)
    name = db.Column(db.String(80), nullable=False)
    creator_id = db.Column(db.BigInteger, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    is_private = db.Column(db.Boolean, nullable=False, default=False)
    password_hash = db.Column(db.String(200))
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow)
    active_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow, index=True)
    closed = db.Column(db.Boolean, nullable=False, default=False)

class RoomMember(db.Model):
    __tablename__ = "room_members"
    room_id = db.Column(db.String(64), db.ForeignKey("rooms.id", ondelete="CASCADE"), primary_key=True)
    user_id = db.Column(db.BigInteger, db.ForeignKey("users.id", ondelete="CASCADE"), primary_key=True)
    role = db.Column(db.String(16), nullable=False, default="listener")  # host/speaker/listener/moderator
    seat_no = db.Column(db.SmallInteger)
    muted = db.Column(db.Boolean, nullable=False, default=False)
    joined_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow)
    last_seen = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow, index=True)
    __table_args__ = (
        CheckConstraint("role IN ('host','speaker','listener','moderator')", name="ck_room_member_role"),
        CheckConstraint("seat_no IS NULL OR (seat_no >= 0 AND seat_no < 21)", name="ck_seat_range"),
        UniqueConstraint("room_id", "seat_no", name="uq_room_seat"),
        Index("ix_room_members_presence", "room_id", "last_seen"),
    )

class RoomMessage(db.Model):
    __tablename__ = "room_messages"
    id = db.Column(db.BigInteger, primary_key=True)
    room_id = db.Column(db.String(64), db.ForeignKey("rooms.id", ondelete="CASCADE"), nullable=False, index=True)
    user_id = db.Column(db.BigInteger, db.ForeignKey("users.id", ondelete="SET NULL"))
    display_name = db.Column(db.String(64), nullable=False, default="")
    body = db.Column(db.String(1000), nullable=False)
    kind = db.Column(db.String(16), nullable=False, default="chat")
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow, index=True)

class WalletTransaction(db.Model):
    __tablename__ = "wallet_transactions"
    id = db.Column(db.BigInteger, primary_key=True)
    user_id = db.Column(db.BigInteger, db.ForeignKey("users.id", ondelete="RESTRICT"), nullable=False, index=True)
    kind = db.Column(db.String(24), nullable=False)
    delta_coins = db.Column(db.BigInteger, nullable=False)
    reference = db.Column(db.String(100), nullable=False, unique=True)
    details = db.Column(db.JSON, nullable=False, default=dict)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow)

class Gift(db.Model):
    __tablename__ = "gifts"
    id = db.Column(db.BigInteger, primary_key=True)
    room_id = db.Column(db.String(64), db.ForeignKey("rooms.id", ondelete="SET NULL"))
    sender_id = db.Column(db.BigInteger, db.ForeignKey("users.id", ondelete="RESTRICT"), nullable=False)
    receiver_id = db.Column(db.BigInteger, db.ForeignKey("users.id", ondelete="RESTRICT"), nullable=False)
    gift_type = db.Column(db.String(32), nullable=False)
    price = db.Column(db.BigInteger, nullable=False)
    receiver_share = db.Column(db.BigInteger, nullable=False)
    fee = db.Column(db.BigInteger, nullable=False)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow)
