from __future__ import annotations
import re, uuid
from datetime import datetime, timezone
from flask import Blueprint, request, jsonify, g, current_app
from sqlalchemy import select, func
from sqlalchemy.exc import IntegrityError
from .extensions import db, limiter
from .models import Room, RoomMember, RoomMessage, User
from .auth import require_telegram_user
from .agora import AgoraCredentials, stable_agora_uid

bp = Blueprint("rooms", __name__, url_prefix="/api")

def _name():
    tg = g.telegram_user
    return (str(tg.get("first_name") or "User")[:30])

def _room(room_id):
    return db.session.get(Room, room_id)

@bp.get("/rooms")
@require_telegram_user
def list_rooms():
    rows = db.session.execute(
        select(Room, func.count(RoomMember.user_id).label("members"))
        .outerjoin(RoomMember, RoomMember.room_id == Room.id)
        .where(Room.closed.is_(False), Room.is_private.is_(False))
        .group_by(Room.id).order_by(Room.active_at.desc()).limit(100)
    ).all()
    return jsonify([{"id": r.id, "name": r.name, "creator": r.creator_id, "count": count}
                    for r, count in rows])

@bp.post("/rooms/create")
@require_telegram_user
@limiter.limit("5 per minute")
def create_room():
    body = request.get_json(silent=True) or {}
    name = str(body.get("room_name", "")).strip()[:80]
    if not name:
        return jsonify(success=False, error="Room name required"), 400
    uid = g.user_id
    user = db.session.get(User, uid)
    if not user:
        user = User(id=uid, username=_name())
        db.session.add(user)
        db.session.flush()
    rid = re.sub(r"[^a-z0-9]+", "", name.lower())[:16] or "room"
    rid = f"{rid}_{uuid.uuid4().hex[:10]}"
    room = Room(id=rid, name=name, creator_id=uid)
    db.session.add(room)
    db.session.add(RoomMember(room_id=rid, user_id=uid, role="host", seat_no=0))
    db.session.commit()
    return jsonify(success=True, room_id=rid)

@bp.post("/rooms/<rid>/join")
@require_telegram_user
def join_room(rid):
    room = _room(rid)
    if not room or room.closed:
        return jsonify(success=False, error="Room not found"), 404
    uid = g.user_id
    user = db.session.get(User, uid)
    if user and user.banned:
        return jsonify(success=False, error="Account is banned"), 403
    if not user:
        user = User(id=uid, username=_name())
        db.session.add(user)
        db.session.flush()
    member = db.session.get(RoomMember, (rid, uid))
    if not member:
        member = RoomMember(room_id=rid, user_id=uid, role="listener")
        db.session.add(member)
    member.last_seen = datetime.now(timezone.utc)
    room.active_at = datetime.now(timezone.utc)
    db.session.commit()
    return jsonify(success=True, role=member.role, seat=member.seat_no)

@bp.post("/rooms/<rid>/seat")
@require_telegram_user
@limiter.limit("20 per minute")
def take_seat(rid):
    body = request.get_json(silent=True) or {}
    try:
        seat = int(body.get("seat"))
    except (TypeError, ValueError):
        return jsonify(success=False, error="Invalid seat"), 400
    if seat < 1 or seat >= 21:
        return jsonify(success=False, error="Choose a speaker seat from 1 to 20"), 400
    uid = g.user_id
    try:
        member = db.session.get(RoomMember, (rid, uid))
        if not member:
            return jsonify(success=False, error="Join the room first"), 403
        # Lock the room row so concurrent seat claims serialize before checking occupancy.
        locked_room = db.session.execute(
            select(Room).where(Room.id == rid).with_for_update()
        ).scalar_one_or_none()
        if not locked_room or locked_room.closed:
            return jsonify(success=False, error="Room not found"), 404
        existing = db.session.execute(select(RoomMember).where(
            RoomMember.room_id == rid, RoomMember.seat_no == seat,
            RoomMember.user_id != uid
        ).with_for_update()).scalar_one_or_none()
        if existing:
            return jsonify(success=False, error="Seat already taken"), 409
        member.role = "speaker"
        member.seat_no = seat
        member.last_seen = datetime.now(timezone.utc)
        db.session.commit()
        return jsonify(success=True, seat=seat)
    except IntegrityError:
        db.session.rollback()
        return jsonify(success=False, error="Seat was taken; refresh and try another"), 409

@bp.post("/rooms/<rid>/listener")
@require_telegram_user
def become_listener(rid):
    member = db.session.get(RoomMember, (rid, g.user_id))
    if not member:
        return jsonify(success=False, error="Not in room"), 403
    if member.role not in ("host", "moderator"):
        member.role, member.seat_no = "listener", None
    db.session.commit()
    return jsonify(success=True, role=member.role)

@bp.post("/rooms/<rid>/exit")
@require_telegram_user
def exit_room(rid):
    member = db.session.get(RoomMember, (rid, g.user_id))
    if member and member.role != "host":
        db.session.delete(member)
        db.session.commit()
    elif member and member.role == "host":
        room = _room(rid)
        if room:
            room.closed = True
            db.session.delete(member)
            db.session.commit()
    return jsonify(success=True)

@bp.get("/rooms/<rid>/state")
@require_telegram_user
def room_state(rid):
    room = _room(rid)
    if not room or room.closed:
        return jsonify(success=False, error="Room not found"), 404
    uid = g.user_id
    member = db.session.get(RoomMember, (rid, uid))
    if not member:
        return jsonify(success=False, error="Join the room first"), 403
    now = datetime.now(timezone.utc)
    member.last_seen, room.active_at = now, now
    since = request.args.get("since", "0")
    try:
        since_id = max(0, int(since))
    except ValueError:
        since_id = 0
    rows = db.session.execute(select(RoomMessage).where(
        RoomMessage.room_id == rid, RoomMessage.id > since_id
    ).order_by(RoomMessage.id.asc()).limit(100)).scalars().all()
    members = db.session.execute(select(RoomMember, User).join(User, User.id == RoomMember.user_id)
        .where(RoomMember.room_id == rid)).all()
    db.session.commit()
    seats = {str(m.seat_no): {"uid": str(m.user_id), "name": u.username, "role": m.role,
                               "muted": m.muted} for m, u in members if m.seat_no is not None}
    current_user = db.session.get(User, uid)
    return jsonify(success=True, name=room.name, host=str(room.creator_id), count=len(members),
        role=member.role, seats=seats,
        messages=[{"id": x.id, "name": x.display_name, "text": x.body, "sys": x.kind != "chat"}
                  for x in rows], coins=current_user.coins if current_user else 0,
        earnings=current_user.earnings if current_user else 0)

@bp.post("/rooms/<rid>/chat")
@require_telegram_user
@limiter.limit("15 per 10 seconds")
def room_chat(rid):
    body = request.get_json(silent=True) or {}
    message = str(body.get("text", "")).strip()[:1000]
    if not message:
        return jsonify(success=False, error="Message required"), 400
    if not db.session.get(RoomMember, (rid, g.user_id)):
        return jsonify(success=False, error="Join the room first"), 403
    row = RoomMessage(room_id=rid, user_id=g.user_id,
                      display_name=_name(), body=message, kind="chat")
    db.session.add(row)
    db.session.commit()
    return jsonify(success=True, id=row.id)

@bp.post("/agora-token")
@require_telegram_user
@limiter.limit("10 per minute")
def agora_token():
    body = request.get_json(silent=True) or {}
    rid = str(body.get("room_id", ""))
    room = _room(rid)
    member = db.session.get(RoomMember, (rid, g.user_id)) if room else None
    if not room or not member or room.closed:
        return jsonify(success=False, error="Join an active room first"), 403
    if member.role == "speaker" or member.role == "host" or member.role == "moderator":
        role = "publisher"
    else:
        role = "subscriber"
    try:
        creds = AgoraCredentials.from_env()
        agora_uid = stable_agora_uid(g.user_id)
        token = creds.build_token(rid, agora_uid, role)
    except (RuntimeError, ValueError) as exc:
        current_app.logger.error("Agora token configuration/error: %s", exc)
        return jsonify(success=False, error="Voice service is not configured"), 503
    return jsonify(success=True, app_id=creds.app_id, channel=rid,
                   token=token, uid=agora_uid, role=role,
                   expires_in=min(creds.ttl_seconds, 3600))
