from __future__ import annotations
import os

class Settings:
    SECRET_KEY = os.environ.get("FLASK_SECRET_KEY", "")
    BOT_TOKEN = os.environ.get("BOT_TOKEN", "")
    ADMIN_IDS = {x.strip() for x in os.environ.get("ADMIN_IDS", "").split(",") if x.strip()}
    AGORA_APP_ID = os.environ.get("AGORA_APP_ID", "")
    AGORA_APP_CERTIFICATE = os.environ.get("AGORA_APP_CERTIFICATE", "")
    DATABASE_URL = os.environ.get("DATABASE_URL", "")
    REDIS_URL = os.environ.get("REDIS_URL", "")
    MAX_CONTENT_LENGTH = 4 * 1024 * 1024
    TOKEN_TTL_SECONDS = int(os.environ.get("AGORA_TOKEN_TTL", "3600"))
    TELEGRAM_AUTH_MAX_AGE = int(os.environ.get("TELEGRAM_AUTH_MAX_AGE", "600"))
    MAX_SPEAKERS = 21
