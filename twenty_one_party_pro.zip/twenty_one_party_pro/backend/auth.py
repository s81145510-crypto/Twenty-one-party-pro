from __future__ import annotations
import hashlib, hmac, json, time
from urllib.parse import parse_qsl
from flask import request, g, jsonify, current_app


def verify_telegram_init_data(init_data: str, bot_token: str, max_age: int = 600):
    if not init_data or not bot_token:
        return None
    try:
        pairs_list = parse_qsl(init_data, keep_blank_values=True, strict_parsing=True)
        pairs = dict(pairs_list)
        if len(pairs) != len(pairs_list):
            return None
        received = pairs.pop("hash", None)
        if not received:
            return None
        auth_date = int(pairs.get("auth_date", "0"))
        now = int(time.time())
        if auth_date > now + 30 or now - auth_date > max_age:
            return None
        check = "\n".join(f"{k}={v}" for k, v in sorted(pairs.items()))
        secret = hmac.new(b"WebAppData", bot_token.encode(), hashlib.sha256).digest()
        calculated = hmac.new(secret, check.encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(calculated, received):
            return None
        user = json.loads(pairs["user"])
        if not isinstance(user, dict) or not user.get("id"):
            return None
        return user
    except (ValueError, TypeError, KeyError, json.JSONDecodeError):
        return None


def require_telegram_user(fn):
    from functools import wraps
    @wraps(fn)
    def wrapper(*args, **kwargs):
        cfg = current_app.config
        user = verify_telegram_init_data(
            request.headers.get("X-Telegram-Init-Data", ""),
            cfg["BOT_TOKEN"], cfg["TELEGRAM_AUTH_MAX_AGE"]
        )
        if not user:
            return jsonify(success=False, error="Unauthorized Telegram session"), 401
        g.telegram_user = user
        g.user_id = int(user["id"])
        return fn(*args, **kwargs)
    return wrapper
