from __future__ import annotations
import hashlib, hmac, os, secrets, time
from dataclasses import dataclass
from typing import Literal

from agora_token_builder import RtcTokenBuilder, Role_Publisher, Role_Subscriber

Role = Literal["publisher", "subscriber"]

@dataclass(frozen=True)
class AgoraCredentials:
    app_id: str
    certificate: str
    ttl_seconds: int = 3600

    @classmethod
    def from_env(cls) -> "AgoraCredentials":
        app_id = os.environ.get("AGORA_APP_ID", "").strip()
        cert = os.environ.get("AGORA_APP_CERTIFICATE", "").strip()
        if not app_id or not cert:
            raise RuntimeError("AGORA_APP_ID and AGORA_APP_CERTIFICATE must be configured")
        if len(app_id) != 32 or len(cert) < 32:
            raise RuntimeError("Agora credentials appear invalid")
        return cls(app_id, cert, int(os.environ.get("AGORA_TOKEN_TTL", "3600")))

    def build_token(self, channel: str, uid: int, role: Role) -> str:
        if not channel or len(channel) > 64:
            raise ValueError("Invalid Agora channel")
        if not 1 <= uid <= 0xFFFFFFFF:
            raise ValueError("Invalid Agora UID")
        agora_role = Role_Publisher if role == "publisher" else Role_Subscriber
        expiry = int(time.time()) + max(300, min(self.ttl_seconds, 3600))
        return RtcTokenBuilder.buildTokenWithUid(
            self.app_id, self.certificate, channel, uid, agora_role, expiry
        )

def stable_agora_uid(telegram_user_id: int) -> int:
    """Stable non-zero uint32 mapping. Collision checks must be enforced by DB in production."""
    raw = hashlib.sha256(f"twenty-one-party:{telegram_user_id}".encode()).digest()
    value = int.from_bytes(raw[:4], "big") or 1
    return value
