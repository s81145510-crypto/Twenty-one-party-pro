from __future__ import annotations
import os
from flask import Flask, jsonify, render_template, g
from .settings import Settings
from .extensions import db, migrate, limiter
from .rooms import bp as rooms_bp
from .auth import require_telegram_user
from .models import User


def make_database_url(url: str) -> str:
    if url.startswith("postgres://"):
        return url.replace("postgres://", "postgresql+psycopg://", 1)
    if url.startswith("postgresql://"):
        return url.replace("postgresql://", "postgresql+psycopg://", 1)
    return url


def create_app(test_config=None):
    app = Flask(__name__, template_folder="../templates")
    app.config.from_object(Settings)
    app.config["BOT_TOKEN"] = Settings.BOT_TOKEN
    app.config["TELEGRAM_AUTH_MAX_AGE"] = Settings.TELEGRAM_AUTH_MAX_AGE
    db_url = make_database_url(Settings.DATABASE_URL)
    app.config["SQLALCHEMY_DATABASE_URI"] = db_url or "sqlite:///twenty_one_party_dev.db"
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
    app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {"pool_pre_ping": True, "pool_recycle": 300}
    if test_config:
        app.config.update(test_config)
    if not app.config.get("SECRET_KEY") and not app.config.get("TESTING"):
        raise RuntimeError("FLASK_SECRET_KEY must be set")
    db.init_app(app)
    migrate.init_app(app, db)
    limiter.init_app(app)
    app.register_blueprint(rooms_bp)

    @app.post("/api/register")
    @require_telegram_user
    def register():
        user = db.session.get(User, g.user_id)
        if user is None:
            tg = g.telegram_user
            user = User(id=g.user_id, username=str(tg.get("first_name") or "User")[:64], coins=100)
            db.session.add(user)
            db.session.commit()
        return jsonify(success=True, user={
            "id": user.id, "username": user.username,
            "coins": user.coins, "earnings": user.earnings,
            "bio": user.bio, "photo": user.photo_url
        })

    @app.get("/")
    def index():
        return render_template("index.html")

    @app.get("/healthz")
    def healthz():
        try:
            db.session.execute(db.text("SELECT 1"))
            return jsonify(status="ok", database="ok")
        except Exception:
            app.logger.exception("Health check failed")
            return jsonify(status="degraded", database="unavailable"), 503

    @app.errorhandler(429)
    def rate_limited(_error):
        return jsonify(success=False, error="Too many requests; try again shortly"), 429

    return app

app = create_app()
