# Twenty One Party PRO – ማብራሪያ

ይህ የPRO አዲስ መሠረታዊ ስሪት ነው። የቀድሞውን ሁሉንም ባህሪያት የጨረሰ ተተኪ አይደለም። የRoom/Voice መሠረትን ከJSON ወደ PostgreSQL ያሻሽላል።

## የተሰሩ ነገሮች

- Telegram WebApp initData ትክክለኛነትን HMAC በመጠቀም ማረጋገጥ፣ እና የቆየ session መከልከል።
- PostgreSQL የUsers, Rooms, Room members, messages, gifts እና wallet ledger መዋቅር።
- 1 Host + 20 Speaker seats። Listener መቀመጫ አይይዝም።
- Database unique constraint ሁለት ሰዎች አንድ seat እንዳይዙ ይከላከላል።
- Agora token ለእያንዳንዱ user የተለየ numeric UID ይጠቀማል፤ UID 0 ለሁሉም አይደለም።
- Host/Speaker ማተሚያ (publisher)፣ Listener ተቀባይ (subscriber)።
- Chat/seat/token/room creation request rate limiting።
- ለAndroid እና Telegram ተስማሚ የሆነ አዲስ ጨለማ ሐምራዊ-ወርቅ UI።

## ገና ያልተጠናቀቁ ነገሮች

የቀድሞው Wallet, Telebirr purchases, Withdrawals, gifts, 6 games, referrals, community posts/jobs እና ሙሉ Admin actions በዚህ መሠረት ውስጥ ገና አልተዘዋወሩም። ስለዚህ አሁን በቀጥታ የTelegram bot WebApp URL ላይ አትቀይረው።

## በAndroid ላይ ለመሞከር

1. ZIP-ውን አውርድ።
2. GitHub ላይ አዲስ repository ወይም የሙከራ branch ፍጠር።
3. ፋይሎቹን አስገባ።
4. Render ላይ አዲስ Web Service እና PostgreSQL ፍጠር።
5. `.env.example` ያለውን ተመልከት እና ምስጢሮቹን በRender Environment ውስጥ አስገባ። `.env` ወደ GitHub ፈጽሞ አትጫን።
6. አሮጌውን Agora Certificate ቀይር፤ ቀድሞ በProject description ውስጥ ታይቷል።
7. በመጀመሪያ በአዲስ URL ላይ ሞክር። ከዚያ በፊት የቀድሞ data import እና የሁሉም API port ይጠናቀቅ።

ትክክለኛው የሚጀመርበት መመሪያ በREADME.md ውስጥ አለ።
