# Twenty One Party PRO – scalable foundation

This repository is a **new PRO foundation**, not yet a complete port of every legacy endpoint. It adds a PostgreSQL-backed room/user model, safer Telegram WebApp validation, role-aware Agora token issuance, seat uniqueness constraints and basic request rate limits.

## What is implemented

- Flask application factory and health check.
- PostgreSQL models for users, rooms, members, messages, gifts and ledger transactions.
- 1 host seat (seat 0) and up to 20 speaker seats (1–20); listeners have no seat.
- Unique database constraint prevents two users claiming the same seat.
- Agora tokens use unique stable numeric UIDs (not UID 0 for every visitor).
- Server decides publisher vs subscriber from the persisted room role.
- Telegram WebApp `initData` HMAC verification, duplicate-key rejection and short freshness window.
- Rate-limited room creation, seat selection, chat and token endpoints.
- Mobile-first dark purple / gold Telegram UI, voice join/listen/speak/mute flow.

## Important: migration is not complete

The legacy application has wallet, manual Telebirr purchases, withdrawals, gifts, games, jobs, community posts, moderation and admin workflows. Those are **not** all ported into this scaffold yet. Do not point the live Telegram bot at this version until wallet/economy routes, admin routes, tests, moderation, payment verification and data migration are complete.

The legacy app uses a JSON file, and its room-state endpoint writes the entire JSON database on every poll. It also currently issues publisher tokens with Agora UID 0 to every user. The new schema avoids those architectural patterns, but a production migration must import existing accounts, balances, transactions, rooms and uploads carefully.

## Local run

Python 3.12 recommended.

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
cp .env.example .env       # set real values in your shell / hosting secrets; do not commit .env
export FLASK_SECRET_KEY="$(python -c 'import secrets; print(secrets.token_urlsafe(48))')"
export BOT_TOKEN="..."
export AGORA_APP_ID="..."
export AGORA_APP_CERTIFICATE="..."
export DATABASE_URL="postgresql://..."
flask --app main db init
flask --app main db migrate -m "initial schema"
flask --app main db upgrade
gunicorn main:app
```

For a local developer-only SQLite smoke test, set `TESTING=1` and configure the app directly in a test runner. Production must use PostgreSQL and migrations.

## Render

Review `render.yaml` and deploy as a **separate service** first. Create a PostgreSQL database and Redis-compatible Key Value instance. Set the environment variables listed below. The starter scaffold currently uses PostgreSQL; Redis is reserved for pub/sub, presence and caching in the next scaling milestone. Do not run schema creation at every web worker startup.

Required environment variables:

- `FLASK_SECRET_KEY`
- `BOT_TOKEN`
- `ADMIN_IDS`
- `AGORA_APP_ID`
- `AGORA_APP_CERTIFICATE` (rotate the previously exposed certificate before setting this)
- `DATABASE_URL`
- `REDIS_URL` (for next-stage distributed presence/pubsub)

## Agora role model

Agora's live-broadcast Web SDK requires `setClientRole('host')` for publishing and `setClientRole('audience')` for receive-only listeners. The token API checks a membership record first and only grants publisher privileges to host/speaker/moderator roles. Speaker seats remain capped at 21, while listeners can join without consuming one of those seats.

The number of possible listeners is not infinite in practice. It is bounded by Agora's service plan/account limits, egress and device/network capacity. Load-test with a measured audience target and confirm current commercial limits with Agora before advertising a concurrency guarantee.

## Before production

1. Rotate the exposed Agora App Certificate; never reuse the value pasted in the previous project description.
2. Add Redis-backed presence and pub/sub (Redis is not yet wired into this first slice).
3. Implement wallet mutations as DB transactions with idempotency keys and a double-entry/auditable ledger.
4. Port gifts, purchases, withdrawal review, referrals, games, posts/jobs and admin routes. Do not trust any price, payout, role or random result from the browser.
5. Store screenshots/profile photos in object storage, not the ephemeral web-service filesystem.
6. Implement moderator controls, speaker request queue, room bans, abuse reports, audit logs and block lists.
7. Add integration tests and load tests; validate Agora token renewals, mobile audio permissions, Bluetooth, reconnects and app background/resume.
8. Perform a one-time JSON-to-PostgreSQL import with a backup and balance reconciliation report.
9. Deploy to a new service/domain first; switch the Telegram WebApp URL only after acceptance testing.

## API slice

- `GET /api/rooms`
- `POST /api/rooms/create`
- `POST /api/rooms/<rid>/join`
- `POST /api/rooms/<rid>/seat`
- `POST /api/rooms/<rid>/listener`
- `GET /api/rooms/<rid>/state`
- `POST /api/rooms/<rid>/chat`
- `POST /api/rooms/<rid>/exit`
- `POST /api/agora-token`
- `GET /healthz`

All `/api` routes require the Telegram WebApp `X-Telegram-Init-Data` header.
