import hashlib, hmac, json, time
from urllib.parse import urlencode
from backend.auth import verify_telegram_init_data


def make_init(token, user, auth_date=None):
    data = {"auth_date": str(auth_date or int(time.time())), "user": json.dumps(user, separators=(",", ":"))}
    check = "\n".join(f"{k}={v}" for k, v in sorted(data.items()))
    secret = hmac.new(b"WebAppData", token.encode(), hashlib.sha256).digest()
    data["hash"] = hmac.new(secret, check.encode(), hashlib.sha256).hexdigest()
    return urlencode(data)


def test_telegram_init_data_valid():
    token = "123:secret"
    raw = make_init(token, {"id": 12345, "first_name": "Test"})
    assert verify_telegram_init_data(raw, token)


def test_telegram_init_data_rejects_tampered():
    token = "123:secret"
    raw = make_init(token, {"id": 12345}) + "&first_name=evil"
    assert verify_telegram_init_data(raw, token) is None


def test_telegram_init_data_rejects_old_auth_date():
    token = "123:secret"
    raw = make_init(token, {"id": 12345}, int(time.time()) - 7200)
    assert verify_telegram_init_data(raw, token, max_age=600) is None
